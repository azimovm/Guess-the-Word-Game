package com.company;

import java.util.*;

public class guessingGame {


    public static void main(String[] args) {
        //this method for reading user inputs
        Scanner scan = new Scanner(System.in);
//libary for the words
        String libary[] =
                {
                        "dog", "cat", "cow", "fish", "bear",
                        "deer", "horse", "pig", "bird", "sheep",
                        "frog", "elephant", "giraffe", "crab", "dolphin",
                        "alligator", "octopus", "kangaroo", "lizard", "monkey"
                };
        //random generater with range 20, form 0 - 20. In c++ use (rnad()%20), please DOUBLE check!
        Random randomWord = new Random();
        int range = 20;
        int r = randomWord.nextInt(range);
        //transfer word form array in to simple string to manipulate easily
        String word = libary[r];
        System.out.println(word);
        System.out.println();

        //please check is it acceptable. I use list to store character and it is best option in this case
        List<Character> playerGuesses = new ArrayList<>();



        System.out.println("Welcome to Pole Chudes\nGuess an animal! " + "The number of letters: " + word.length());
        printWordState(word, playerGuesses);
        while (true) {
                playerLetters(scan, word, playerGuesses);
                if(printWordState(word, playerGuesses)){
                    break;
                }
        }
        System.out.println("You win!");
    }
//two methods for showing "-" instead letters and checking does letter exist in the word
    private static void playerLetters(Scanner scan, String word, List<Character> playerGuesses) {
        System.out.println("Enter the letter:  ");
        String insertedLetter = scan.nextLine();

        playerGuesses.add(insertedLetter.charAt(0));
    }

    private static boolean  printWordState(String word, List<Character> playerGuesses) {
        int count = 0;
        for (int i = 0; i< word.length(); i++){
            if (playerGuesses.contains(word.charAt(i))){
                System.out.print(word.charAt(i));
                count++;
            }else {
                System.out.print("-");
            }
        }
        System.out.println();
        return (word.length()==count);
    }
}
